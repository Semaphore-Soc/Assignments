struct cond_t{ 
    int dummy;
};
typedef struct cond_t cond_t;